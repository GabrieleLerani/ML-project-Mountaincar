import tensorflow as tf
import gymnasium as gym
import random
import matplotlib.pyplot as plt
import numpy as np
from keras.models import Sequential
from keras.models import load_model
from keras.layers import Dense
from keras.layers import Dropout



class RLAgent:
    def __init__(
        self,
        env: gym.Env,
        initial_epsilon: float,
        epsilon_decay: float,
        final_epsilon: float,
        gamma: float,
        lr: float,
        dropout_rate: float = 0.3
    ):

        self.state_shape = env.observation_space.shape
        self.actions = env.action_space.n
        self.gamma = gamma
        self.epsilon = initial_epsilon
        self.epsilon_decay = epsilon_decay
        self.final_epsilon = final_epsilon
        self.lr = lr
        self.train_net = self.build_model()
        self.loss_values = list()
        self.dropout_rate = dropout_rate

    def save_model(
        self,
        model_name:str,
        episode: int
    ):
        """
        Saveing model
        """
        self.train_net.save(f'models/{model_name}/trainNetwork{episode}.h5')

    def load(
        self,
        model_name:str,
        episode: int
    ):
        self.train_net = load_model(f'models/{model_name}/trainNetwork{episode}.h5')

    @staticmethod
    def get_optmizer(lr: int):

        # apply learning rate EsponentialDecay
        lr_schedule = tf.keras.optimizers.schedules.ExponentialDecay(
            lr,
            decay_steps=500,
            decay_rate=0.96,
            staircase=True
        )

        # define an optimizer with a learning rate schedule to decrease it over time
        opt = tf.optimizers.Adam(learning_rate=lr_schedule)
        return opt


    def build_model(self):
        """
        Builds a deep neural net which predicts the Q values for all possible
        actions given a state. The input should have the shape of the state
        (which is 2 in MountainCar), and the output should have the same shape as
        the action space (which is 2 in MountainCar) since we want 1 Q value per
        possible action.

        :return: the Q network
        """


        model = Sequential()
        model.add(Dense(24, input_shape=self.state_shape, activation='relu',
                        kernel_initializer='he_uniform'))
        model.add(Dropout(0.0))
        model.add(Dense(48, activation='relu',
                        kernel_initializer='he_uniform'))
        model.add(Dropout(0.0))

        model.add(Dense(self.actions, activation='linear',
                        kernel_initializer='he_uniform'))

        model.compile(optimizer=self.get_optmizer(self.lr), loss='mse', metrics=["mse"])
        return model


    def update_dropout(self):
        # Enable dropout after the specified episode
        for layer in self.train_net.layers:
            if isinstance(layer, Dropout):
                layer.rate = self.dropout_rate

    def policy(self,state) -> int:
        action_q = self.train_net(np.atleast_2d(state))
        return np.argmax(action_q[0], axis=0)


    def get_action(self, obs) -> int:
        """
        Get an action with an epsilon greedy policy
        """
        greedy = random.random() > self.epsilon

        # exploitation
        if greedy:

            # use the train net to get the action value given a state
            return self.policy(obs)

        # exploration
        else:
             return np.random.choice(self.actions)

    def train(self, batch):
        """
        Train the network with a batch sample using a train net
        """

        state, next_state, action, reward, terminated = batch

        # get the current q value for that state, it will be a value for both actions
        current_q = self.train_net(state)

        # copy that value of the current q-value into a target variable
        target_q = np.copy(current_q)

        # using the train network get the q-value of the next state
        next_q = self.train_net(next_state)

        # among the q-values returned by the target network select the best
        max_next_q = np.amax(next_q, axis=1)

        for i in range(state.shape[0]):

            target_q[i][action[i]] = reward[i] + self.gamma * (1 - terminated[i]) * max_next_q[i]

        # fit the train model
        history = self.train_net.fit(x=state, y=target_q, epochs=1,verbose=0)

        # add to list
        self.loss_values.append(history.history["loss"])

        # return the loss and learning rate
        return round(self.train_net.optimizer.lr.numpy(), 5)

    def decay_epsilon(self):
        """ Decay epsilon value by a constant"""
        self.epsilon = max(self.final_epsilon, self.epsilon * self.epsilon_decay)

    def plot_loss(self):
        plt.plot(range(len(self.loss_values)), self.loss_values)
        plt.xlabel('Episode')
        plt.ylabel('Loss')
        plt.show()

    def plot_rew(self,aggr_ep_rewards,model_name):

        plt.plot(aggr_ep_rewards.get('ep'), aggr_ep_rewards.get('avg'), label="avg rewards")
        plt.plot(aggr_ep_rewards.get('ep'), aggr_ep_rewards.get('min'), label="min rewards")
        plt.plot(aggr_ep_rewards.get('ep'), aggr_ep_rewards.get('max'), label="max rewards")
        plt.legend(loc=4)
        plt.xlabel('Episode')
        plt.ylabel('Reward')
        plt.ylim(-200, None)
        plt.show()


    def plot_policy(self,actions):
        temp_action_x = list(actions.keys())

        action_labels = {0: "left", 1: "stay", 2: "right"}
        action_x = [action_labels[a] for a in temp_action_x]
        action_y = list(actions.values())

        colors = ['blue', 'green', 'orange']

        fig, ax = plt.subplots()
        ax.bar(action_x, action_y, color=colors)
        ax.set_ylabel('Ocurrences')
        ax.set_title('Actions')
        ax.legend(title='Actions policy')

        plt.show()

