import gymnasium as gym
import os
import numpy as np
from collections import deque
from Agent import RLAgent
from ReplayBuffer import ReplayBuffer


EPISODE = 4000                      # Number of episode to play
EPISODE_MAX_LENGTH = 200            # This number depends on the environment
SAVE_MODEL_STEP = EPISODE // 8      # Frequency of saving model
DROPOUT = 750                       # Point of insertion of dropout layers
GAMMA = 0.99                        # Discount factor
EXP_MAX_SIZE = 10_000               # Max batch size of past experience previous 10000
#LR = 0.001251                      # NN learning rate
LR = 0.01251                        # Different learning rate
EPS_MAX = 1.0                       # Initial exploration probability
EPS_MIN = 0.001                     # Final exploration probability before: 0,00001
DECAY = 0.85                        # Decay value
BATCH_SIZE = 32                     # Sample to get from experiences
PLOT = 500                          # Frequency of plotting graphs

win = 0
scores = list()

model_name = f'LR: {LR} - GAMMA: {GAMMA} -' \
             f' EPISODES: {EPISODE}'\
             f' EPSILON: {EPS_MAX}'\
             f" BATCH: {BATCH_SIZE}"


# create model directory for storing models
if not os.path.exists("models/"):
        os.makedirs("models/")
        os.mkdir(f'models/{model_name}')


env = gym.make('MountainCar-v0')
agent = RLAgent(
        env=env,
        lr=LR,
        initial_epsilon=EPS_MAX,
        epsilon_decay=DECAY,
        final_epsilon=EPS_MIN,
        gamma=GAMMA,
        )


buffer = ReplayBuffer(
                      exp_max_size=EXP_MAX_SIZE,
                      batch_size=BATCH_SIZE
                      )

time_scores = deque(maxlen=100)
lr_value = 0

aggr_ep_rewards = {'ep': [], 'avg': [], 'min': [], 'max': []}

for episode_cnt in range(1, EPISODE + 1):
  state, _ = env.reset()
  terminated = False

  # play the game and collect experience
  for step in range(1, EPISODE_MAX_LENGTH + 1):
    action = agent.get_action(state)
    next_state, reward, terminated, truncated, _ = env.step(action)

    # add experience tu the buffer
    buffer.add_experience((state, next_state, reward, action, terminated))

    # agent won't start learning if there isn't enough experience
    if buffer.get_exp_size() > BATCH_SIZE and step % 15 == 0:
        gameplay_experience_batch = buffer.sample_game_batch()
        lr_value = agent.train(gameplay_experience_batch)

    # set state to next state
    state = next_state


    if terminated or truncated:

        # store current time for that episode
        time_scores.append(step * -1)

        # compute avg score of the last 100 episodes
        avg_reward = np.mean(time_scores)
        min_reward = min(time_scores)
        max_reward = max(time_scores)
        aggr_ep_rewards['ep'].append(episode_cnt)
        aggr_ep_rewards['avg'].append(avg_reward)
        aggr_ep_rewards['min'].append(min_reward)
        aggr_ep_rewards['max'].append(max_reward)

        # store avg score
        scores.append(avg_reward)


        print(f"Episode {episode_cnt}/{EPISODE}, e {agent.epsilon:.6f}, avg reward {avg_reward:.2f}, time {step}, lr :{lr_value:.6f}")
        break

  if episode_cnt % SAVE_MODEL_STEP == 0:
    agent.save_model(model_name, episode_cnt)

  agent.decay_epsilon()

  # show avarage reward
  if episode_cnt % PLOT == 0:
    agent.plot_rew(aggr_ep_rewards,model_name)
    agent.plot_loss()

  if episode_cnt == DROPOUT:
    agent.update_dropout()
    print("Starting dropout")


#training_result(agent,model_name)