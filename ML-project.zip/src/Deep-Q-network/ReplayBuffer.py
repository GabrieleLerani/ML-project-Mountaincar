from collections import deque
import random
import numpy as np

class ReplayBuffer:
  def __init__(self,exp_max_size,batch_size):
    self.exp_max_size = exp_max_size
    self.batch_size = batch_size
    self.experiences = deque(maxlen=exp_max_size)

  def get_exp_size(self):
    """
    Get experiences length
    """
    return len(self.experiences)

  def add_experience(self,exp):
    """
    Add new experience to buffer
    """
    # oldest item are automatically removed when dimensione is over max_exp_size
    self.experiences.append(exp)


  def sample_game_batch(self):
    """
    Sample game batch for training loop
    """
    # take a sample of batch size
    sampled_gameplay_batch = random.sample(self.experiences, self.batch_size)

    # define state, next_state, action ,reward, done
    state_batch, next_state_batch, action_batch, reward_batch, done_batch= [], [], [], [], [],

    # for each experience in the batch get a sample
    for gameplay_experience in sampled_gameplay_batch:
      state_batch.append(gameplay_experience[0])
      next_state_batch.append(gameplay_experience[1])
      reward_batch.append(gameplay_experience[2])
      action_batch.append(gameplay_experience[3])
      done_batch.append(gameplay_experience[4])

    return np.array(state_batch), np.array(next_state_batch), np.array(action_batch), np.array(reward_batch), np.array(done_batch)