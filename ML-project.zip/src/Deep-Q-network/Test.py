import gymnasium as gym
from Agent import RLAgent
from tqdm import tqdm
import argparse

def training_result(model_name,episode,render,episodes):
  
  env = gym.Env
  if render:
    env = gym.make('MountainCar-v0', render_mode = "human")
  else: 
    env = gym.make('MountainCar-v0')


  total_reward = 0.0
  win = 0
  actions = {0:0,
             1:0,
             2:0}

  agent = RLAgent(
        env=env,
        lr=0.01,
        initial_epsilon=1.0,
        epsilon_decay=0.99,
        final_epsilon=0.001,
        gamma=0.99,
        )

  agent.load(model_name,episode)


  for i in tqdm(range(episodes)): # Play 10 episode and take the average
    state, _ = env.reset()
    done = False
    truncated = False
    episode_reward = 0.0
    while not (done or truncated):
      action = agent.policy(state)

      next_state, reward, done,truncated, info = env.step(action)

      # increment action
      actions[action] += 1


      # Count number of win
      if next_state[0] >= 0.5:
        win += 1

      episode_reward += reward
      state = next_state

    total_reward += episode_reward

  average_reward = total_reward / episodes
  accuracy = win / episodes

  print(f"Average reward: {average_reward}, Accuracy {accuracy:.4f}")
  agent.plot_policy(actions)


if __name__=="__main__":
    
    parser = argparse.ArgumentParser(description="""deep q-network testing""")

    
    parser.add_argument(
        "-r",
        "--render",
        action="store_true",
        help="Render the environment"
    )
    
    parser.add_argument(
        "-e",
        "--episode",
        type=int,
        required=True,
        help="Set number of episode to test the model"
    )
    
    args = parser.parse_args()

    render = args.render
    episode_num = args.episode
    model_episode = "2500"
    model_name = "LR: 0.01251 - GAMMA: 0.99 - EPISODES: 4000 EPSILON: 1.0"
  
    training_result(model_name,model_episode,render,episode_num)

