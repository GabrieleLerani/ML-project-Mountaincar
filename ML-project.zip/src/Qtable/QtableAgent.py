import numpy as np
import gymnasium as gym
import matplotlib.pyplot as plt
import random
from gymnasium import wrappers
from tqdm import tqdm

class RLAgent:
    def __init__(
        self,
        learning_rate: float = 0.1,
        initial_epsilon: float = 0.5,
        epsilon_decay: float = 0.00002,
        final_epsilon: float = 0.1,
        action_space: int = 3,
        discount_factor: float = 0.95,
        env: gym.Env = None,
        env_size: int = 50,

    ):
        """Initialize a Reinforcement Learning agent with an empty dictionary
        of state-action values (q_values), a learning rate and an epsilon.

        Args:
            learning_rate: The learning rate
            initial_epsilon: The initial epsilon value
            epsilon_decay: The decay for epsilon
            final_epsilon: The final epsilon value
            action_space: The number of action for the environment
            discount_factor: The discount factor for computing the Q-value
        """
        self.env = env
        self.actions = action_space
        self.lr = learning_rate
        self.discount_factor = discount_factor
        self.epsilon = initial_epsilon
        self.epsilon_decay = epsilon_decay
        self.final_epsilon = final_epsilon
        self.training_error = []
        self.discrete_size = [env_size] * len(env.observation_space.high)
        self.discrete_win_size = (env.observation_space.high - env.observation_space.low) / self.discrete_size
        self.q_values = np.random.uniform(low=-2, high=0, size=(self.discrete_size + [env.action_space.n]))

    def policy(self,state) -> int:
        state = self.get_discrete_state(state)
        return int(np.argmax(self.q_values[state]))


    def get_action(self, obs: np.ndarray) -> int:
        """
        Returns the best action with probability (1 - epsilon)
        otherwise a random action with probability epsilon to ensure exploration.
        """
        greedy = random.random() > self.epsilon

        # exploitation
        if greedy:
            # use the train net to get the action value given a state
            return self.policy(obs)

        # exploration
        else:
             return np.random.choice(self.actions)


    def get_discrete_state(self,state):
        """
        Return a discrete representation of the state, this simplify the learning process
        by reducing the complexity of the state and allow fixed size q-table
        """
        discrete_state = (state - self.env.observation_space.low) / self.discrete_win_size
        return tuple(discrete_state.astype(np.int))


    def save_qtable(
        self,
        model_name: str,
        episode: int,
    ):
        """
        Saving Q-Tables
        """
        np.save(f'./q_tables/{model_name}/{episode}-qtable.npy', self.q_values)

    def load_qtable(
        self,
        model_name: str,
        episode: str
    ):
        """
        Load Q-Table
        """

        self.q_values = np.load(f'./q_tables/{model_name}/{episode}-qtable.npy')


    def update(
        self,
        obs: np.ndarray,
        action: int,
        reward: float,
        terminated: bool,
        next_obs: np.ndarray,
    ):
        """Updates the Q-value of an action."""

        # convert np.ndarray to hashable object
        obs = self.get_discrete_state(obs)
        next_obs = self.get_discrete_state(next_obs)


        # get the future q_value for the current observation
        future_q_value = (not terminated) * np.max(self.q_values[next_obs])

        # get the difference between current q_value and next observation
        temporal_difference = (
            reward + self.discount_factor * future_q_value - self.q_values[obs + (action,)]
        )

        # update the q values for the current observation and action
        self.q_values[obs + (action,)] = (
            self.q_values[obs + (action,)] + self.lr * temporal_difference
        )

        # store the training error, the goal is to reduce it
        self.training_error.append(temporal_difference)

    def decay_epsilon(self):
        """ Decay epsilon value by a constant"""
        self.epsilon = max(self.final_epsilon, self.epsilon - self.epsilon_decay)

    def plot_stats(self,env):
        rolling_length = 500
        fig, axs = plt.subplots(ncols=2, figsize=(12, 5))
        axs[0].set_title("Episode rewards")
        # compute and assign a rolling average of the data to provide a smoother graph
        reward_moving_average = (
            np.convolve(
                np.array(env.return_queue).flatten(), np.ones(rolling_length), mode="valid"
            )
            / rolling_length
        )
        axs[0].plot(range(len(reward_moving_average)), reward_moving_average)

        axs[1].set_title("Training Error")
        training_error_moving_average = (
            np.convolve(np.array(self.training_error), np.ones(rolling_length), mode="same")
            / rolling_length
        )
        axs[1].plot(range(len(training_error_moving_average)), training_error_moving_average)
        plt.tight_layout()
        plt.show()

    def plot_policy(self,actions):
        temp_action_x = list(actions.keys())

        action_labels = {0: "left", 1: "stay", 2: "right"}
        action_x = [action_labels[a] for a in temp_action_x]
        action_y = list(actions.values())

        colors = ['blue', 'green', 'orange']

        fig, ax = plt.subplots()
        ax.bar(action_x, action_y, color=colors)
        ax.set_ylabel('Ocurrences')
        ax.set_title('Actions')
        ax.legend(title='Actions policy')

        plt.show()