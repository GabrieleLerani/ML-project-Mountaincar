
import gymnasium as gym
import argparse
from tqdm import tqdm
from QtableAgent import RLAgent


def training_result(model_name,episode,render,episodes):
  
  env = gym.Env
  if render:
    env = gym.make('MountainCar-v0', render_mode = "human")
  else: 
    env = gym.make('MountainCar-v0')

  total_reward = 0.0
  win = 0
  actions = {0:0,
             1:0,
             2:0}

  agent = RLAgent(env=env)
  agent.load_qtable(model_name, episode)


  for i in tqdm(range(episodes)): # Play 10 episode and take the average
    state, _ = env.reset()
    done = False
    truncated = False
    episode_reward = 0.0
    while not (done or truncated):
      action = agent.policy(state)

      next_state, reward, done,truncated, info = env.step(action)

      # increment action
      actions[action] += 1


      # Count number of win
      if next_state[0] >= 0.5:
        win += 1

      episode_reward += reward
      state = next_state


    total_reward += episode_reward

  average_reward = total_reward / episodes
  accuracy = win / episodes

  print(f"Average reward: {average_reward}, Accuracy {accuracy:.4f}")
  agent.plot_policy(actions)

if __name__=="__main__":


    parser = argparse.ArgumentParser(description="""deep q-network testing""")

    
    parser.add_argument(
        "-r",
        "--render",
        action="store_true",
        help="Render the environment"
    )
    
    parser.add_argument(
        "-e",
        "--episode",
        type=int,
        required=True,
        help="Set number of episode to test the model"
    )
    
    args = parser.parse_args()

    render = args.render
    episode_num = args.episode
    
    qtable_name = f'LR: 0.1 - DISCOUNT: 0.95 -' \
                f' EPISODES: 90000'\
                f' EPSILON: 0.5'\
                f' TABLE_SIZE: 50'

    qtable_episode = "90000"


    training_result(qtable_name,qtable_episode,render,episode_num)