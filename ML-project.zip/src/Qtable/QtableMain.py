import gymnasium as gym
from gymnasium import wrappers
from collections import deque
from QtableAgent import RLAgent
import os
import numpy as np


def initialize_directories(model_name):
    """
    Creates new directory in ./q_tables/
    """
    # create model directory for storing models
    if not os.path.exists("q_tables/"):
        os.makedirs("q_tables/")
        os.mkdir(f'./q_tables/{model_name}')



EPISODES = 90_000             # number of episode to play
UPGRADE_STEP =10_000            # frequency of target network upgrade
GAMMA = 0.95                  # discount factor
LR = 0.1                      # q-table learning rate
EPS_MAX = 0.5               # Initial exploration probability
EPS_MIN = 0.1           # Final exploration probability
DECAY = EPS_MAX / (EPISODES - 1)
TABLE_SIZE = 50     # used to compute the size of the q table

reward_sum = 0
win = 0
scores = list()

model_name = f'LR: {LR} - DISCOUNT: {GAMMA} -' \
             f' EPISODES: {EPISODES}'\
             f' EPSILON: {EPS_MAX}'\
             f' TABLE_SIZE: {TABLE_SIZE}'

initialize_directories(model_name)


env = gym.make('MountainCar-v0')
agent = RLAgent(
    learning_rate=LR,
    initial_epsilon=EPS_MAX,
    epsilon_decay=DECAY,
    final_epsilon=EPS_MIN,
    action_space=env.action_space.n,
    discount_factor=GAMMA,
    env=env,
    env_size=TABLE_SIZE,
)

reward_sum = 0
time_scores = deque(maxlen=100)


env = wrappers.RecordEpisodeStatistics(env, deque_size=EPISODES)
for episode in range(1,EPISODES + 1):
    obs, info = env.reset()
    done = False

    step = 1
    # play one episode
    while not done:

        # get an action according to epsilon greedy policy
        action = agent.get_action(obs)

        # execute the action
        next_obs, reward, terminated, truncated, info = env.step(action)


        # update the agent
        agent.update(obs, action, reward, terminated, next_obs)

        # update if the environment is done and the current obs
        done = terminated or truncated

        # upgrade to next obs
        obs = next_obs

        if done:

            # store current time for that episode
            time_scores.append(step)

            # compute avg score
            scores_avg = np.mean(time_scores) * -1

            if episode % 200 == 0:
                print(f"Episode {episode}/{EPISODES}, e {agent.epsilon:.6f}, avg reward {scores_avg:.2f}, state {next_obs}, time {step}")
            break

        # increment step
        step+=1

    # Save progress every UPGRADE STEP
    if episode % UPGRADE_STEP == 0 and episode > 0:
        agent.save_qtable(model_name,episode)

    agent.decay_epsilon()

# plot stats
agent.plot_stats(env)